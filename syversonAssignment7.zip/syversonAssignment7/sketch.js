function setup() {
  createCanvas(400, 400);
}

function draw() {
  let c = color(0,150,255);
  let x = mouseX;
  let y = mouseY;
  background(c);
  hurricane(x,y);
  printCords(true);//if true, then print
}


function hurricane(mouseX, mouseY) {
  let c = color(0,150,255);
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  angleMode(DEGREES);

  translate(width / 2, height / 2);
  push();
  rotate(a);
  fill(c);
  circle(0,10,45,50);
  rotate(a);
  fill(255);
  circle(0,10,90,100);
  fill(c);
  circle(0,10,45,50);
  pop();
  angleMode(RADIANS);
  rotate(a);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD); 
  rotate(180);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD);
  rotate(180);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD);
  
  scale(1.1);
  rotate(a);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD); 
  rotate(a+180);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD);
  rotate(a+180);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD);
  
  scale(1.2);
  rotate(a);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD); 
  rotate(a+300);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD);
  rotate(a+300);
  arc(50, 50, 180, 80, 0, PI + QUARTER_PI, CHORD);
  
  for(let i = 0; i < 10; i++){
  let a = random(-100,100);
  let b = random(-100,100);
  let c = random(10);
  let d = random(5);
  circle(a,b,c,d);
  }
}
function printCords(a){
  if(a == true){
    print("mouseX = " + mouseX + "||  mouseY = " + mouseY  );
  }
}