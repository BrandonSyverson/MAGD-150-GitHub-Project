var x = [];
var y = []; 
var cloudX = [];
var cloudY = [];
var treeColor = [];
var mX = [];
var mY = [];
var num = 50;

function setup() {
	createCanvas(700, 700);
	noStroke();
  for (var a = 0; a < 3; a++){
    treeColor[a] = random(50,200);
  }
  
  for (var i = 0; i < 10000; i++) {
    x[i] = random(0,700);
    y[i] = random(0, -30000);
    cloudX[i] = random(700,-100000);
    cloudY[i] = random(-20,20);
  }
  
  //mouse cloud
  for (var mc = 0; mc < num; mc++) {
	mX[mc] = 0;
	mY[mc] = 0;
  }
}

function draw() {
  background(0,220,255);
  scenary();
 
  //rain
  fill(0,180,255);
  for (var i = 0; i < y.length; i++) {
    y[i] += 2.5;
    ellipse(x[i],y[i],10,20);
    }
  
  //clouds
  fill(240);
    for (var z = 0; z < 1000; z++) {
      cloudX[z] += 2;
    ellipse(cloudX[z],cloudY[z],200,200);
    }
  
  //mouse cloud
  for (var mc = num-1; mc > 0; mc--) {
	mX[mc] = mX[mc-1];
	mY[mc] = mY[mc-1];
  }
	mX[0] = mouseX; // Set the first element
	mY[0] = mouseY; // Set the first element
	
  for (var mc = 0; mc < num; mc++) {
	fill(mc * 4);
	ellipse(mX[mc], mY[mc], 40, 40);
  }
  
  consoleText();
}

function scenary(){
  //hills
  fill(125,200,0);
  circle(300,850,900);
  fill(125,250,0);
  circle(100,900,900);
  fill(142,320,0);
  circle(500,900,900);
  
  //trees
  tree(75,350,0);
  tree(150,400,1);
  tree(40,500,2);

}
function tree(x,y,number){
  fill(150,75,0);
  rect(x,y,50,150);
  fill(treeColor[number],255,150);
  circle(x+25,y,100);
}
function consoleText(){
  print('cloudX length = ' + cloudX.length);
}