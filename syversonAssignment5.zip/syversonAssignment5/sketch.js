//make an old tv where a button turns it on and another button turns it off, a third button does something else such as change brightness or change whats on the screen

let x, y;//channel3

function setup() {
  createCanvas(600, 400);
  frameRate(60);
  screen = 100;
  screenOn = false;
  channel = 0;
  maxChannel = 3;
  minChannel = 1;
  b1pushed = false;
  b1a = 170;
  b1b = 280;
  b1c = 150;
  b1d = 100;
  b2pushed = false;
  b2a = 80;
  b2b = 330;
  b2c = 100;
  b2d = 100;
  b3pushed = false;
  b3a = 400;
  b3b = 320;
  b3c = 60;
  b3d = 60;
  //  triangle(440, 340, 420, 350, 440, 360);(- + + = - -)
  t1a = 450;
  t1b = 330;
  t1c = 410;
  t1d = 350;
  t1e = 450;
  t1f = 370;
  b4pushed = false;
  b4a = 470;
  b4b = 320;
  b4c = 60;
  b4d = 60;
  //triangle(480, 330, 520, 350, 480, 370);
  t2a = 480;
  t2b = 330;
  t2c = 520;
  t2d = 350;
  t2e = 480;
  t2f = 370;
  x = width; // 2;//channel3
  y = height;//channel3
}

function draw() {
  background(220);
  colorOne = color(167,175,253);
  colorTwo = color(91,107,252);
  colorThree = color(230,61,0);
  colorFour = color(227,113,68);
  colorFive = color(57,138,11);
  colorSix = color(103,214,39);
  
  //TV border
  fill(100);
  rect(0,0,600,400);
  fill(0);
  rect(10,10,580,380);
  
  //TV screen
  fill(screen);
  rect(40,40,520,220);
  
  
  //Channel0
  if(channel == 0){
    fill(180);
     }
  
  //Channel1
  if(channel == 1){
    fill(180);
    fill(colorTwo);
    rect(40,40,86,220);
    fill(colorFive);
    rect(125,40,86,220);
    fill(colorThree);
    rect(210,40,86,220);
    fill(colorOne);
    rect(295,40,86,220);
    fill(colorSix);
    rect(380,40,86,220);
    fill(colorFour);
    rect(465,40,95,220)
  }
  
  //Channel2
  if(channel == 2){
    personX = 375;
    personX = personX + random(-1, 1);
    tvX = 80;
    tvX = tvX + random(-1, 1);
    noStroke();
    fill(180);
    ellipse(personX,160,100,100);//375
    arc(personX, 260, 150, 200, PI, TWO_PI);
    rect(tvX,80,200,100);
    movingLine();
  }
  
  //Channel3
  if(channel == 3){
    channel3();
    movingLine();
  }
  
  //button1
  mouseOverButtonOne(170,280,320,380);
  fill(buttonOneColor);
  rect(b1a,b1b,b1c,b1d);
  
  
  //button2
  mouseOverButtonTwo(80,330,100,100);
  fill(buttonTwoColor);
  ellipse(b2a,b2b,b2c,b2d);
 
  //button3
  mouseOverButtonThree(400,320,460,380);
  fill(buttonThreeColor);
  rect(b3a, b3b, b3c, b3d);
  fill(255);
  triangle(t1a, t1b, t1c, t1d, t1e, t1f);
 
  //triangle(440, 340, 420, 350, 440, 360);
  
  //button4
  mouseOverButtonFour(470,320,530,380);
  fill(buttonFourColor);
  rect(b4a,b4b,b4c,b4d);
  fill(255);
  triangle(t2a, t2b, t2c, t2d, t2e, t2f);
  //(+,+,-,=,+,-)
  //triangle(490, 340, 510, 350, 490, 360);
  
  
  
  
  
  //debug
  debugConsole(true);
  
}

function debugConsole(a) {
  if(a == true){
  console.log("x -> " + mouseX + "  ||  y -> " + mouseY);
    }
  }
function mouseOverButtonOne(a,b,c,d) {
   if(mouseX > a && mouseX < c && mouseY > b && mouseY < 380){
    buttonOneColor = colorOne;
     }
  else{
    buttonOneColor = colorTwo;
  }
}
function mouseOverButtonTwo(a,b,c,d) {
  radius = 50;
  var e = dist(mouseX, mouseY, a, b)
     if(e < radius){
    buttonTwoColor = colorFour;
     }
  else{
    buttonTwoColor = colorThree;
  }
}
function mouseOverButtonThree(a,b,c,d) {
   if(mouseX > a && mouseX < c && mouseY > b && mouseY < 380){
    buttonThreeColor = colorSix;
     }
  else{
    buttonThreeColor = colorFive;
  }
}
function mouseOverButtonFour(a,b,c,d) {
   if(mouseX > a && mouseX < c && mouseY > b && mouseY < 380){
    buttonFourColor = colorSix;
     }
  else{
    buttonFourColor = colorFive;
  }
}
function mouseClicked(){
  radius = 50;
  var d = dist(mouseX, mouseY, 80, 330);
  
  if(mouseX > 170 && mouseX < 320 && mouseY > 280 && mouseY < 380){
    console.log("Button 1 clicked!");
    screen = 255;
    screenOn = true;
    channel = 1;
    if(b1pushed == false){
      b1pushed = true;
      b1a = b1a + 10;
      b1b = b1b + 10;
      b1c = b1c - 20; 
      b1d = b1d - 20;
      setTimeout(() => b1a = b1a - 10,500);
      setTimeout(() => b1b = b1b - 10,500);
      setTimeout(() => b1c = b1c + 20,500);
      setTimeout(() => b1d = b1d + 20,500);
      setTimeout(() => b1pushed = false,1000);
      }
    }
  else if(d < radius){
    console.log("Button 2 clicked!");   
    screen = 100;
    channel = 0;
    screenOn = false;
    if(b2pushed == false){
      b2pushed = true;
      b2c = b2c - 20; 
      b2d = b2d - 20;
      setTimeout(() => b2c = b2c + 20,500);
      setTimeout(() => b2d = b2d + 20,500);
      setTimeout(() => b2pushed = false,500);
      }
    }
  else if(mouseX > 400 && mouseX < 460 && mouseY > 320 && mouseY < 380){
    console.log("Button 3 clicked!"); 
    
    
    if(b3pushed == false){
      b3pushed = true;
      b3a = b3a + 10;
      b3b = b3b + 10;
      b3c = b3c - 20; 
      b3d = b3d - 20;//(- + + = - -)
      t1a = t1a - 10;
      t1b = t1b + 10;
      t1c = t1c + 10;
      t1d = t1d + 0;
      t1e = t1e - 10;
      t1f = t1f - 10;
      setTimeout(() => t1a = t1a + 10,500);
      setTimeout(() => t1b = t1b - 10,500);
      setTimeout(() => t1c = t1c - 10,500);
      setTimeout(() => t1d = t1d - 0,500);
      setTimeout(() => t1e = t1e + 10,500);
      setTimeout(() => t1f = t1f + 10,500);
      setTimeout(() => b3a = b3a - 10,500);
      setTimeout(() => b3b = b3b - 10,500);
      setTimeout(() => b3c = b3c + 20,500);
      setTimeout(() => b3d = b3d + 20,500);
      setTimeout(() => b3pushed = false,1000);
       }
    
    
    if(screenOn == true && channel != minChannel){
      channel--;
      console.log("Channel -1 : Channel = " + channel);
      }
    else if(channel == 0){
      console.log("Minimum channel reached!");
    }
    }
  else if(mouseX > 470 && mouseX < 530 && mouseY > 320 && mouseY < 380){
    console.log("Button 4 clicked!");
    
      if(b4pushed == false){
      b4pushed = true;
      b4a = b4a + 10;
      b4b = b4b + 10;
      b4c = b4c - 20; 
      b4d = b4d - 20;
      t2a = t2a + 10;
      t2b = t2b + 10;
      t2c = t2c - 10;
      t2d = t2d + 0;
      t2e = t2e + 10;
      t2f = t2f - 10;
      setTimeout(() => t2a = t2a - 10,500);
      setTimeout(() => t2b = t2b - 10,500);
      setTimeout(() => t2c = t2c + 10,500);
      setTimeout(() => t2d = t2d - 0,500);
      setTimeout(() => t2e = t2e - 10,500);
      setTimeout(() => t2f = t2f + 10,500);
      setTimeout(() => b4a = b4a - 10,500);  //(+,+,-,=,+,-)
      setTimeout(() => b4b = b4b - 10,500);
      setTimeout(() => b4c = b4c + 20,500);
      setTimeout(() => b4d = b4d + 20,500);
      setTimeout(() => b4pushed = false,1000);
       }
    
    
    if(screenOn == true && channel != maxChannel){
      channel++;
      console.log("Channel +1 : Channel = " + channel);
      }
    else{
      console.log("Maximum channel reached!");
    }
    }
}
function movingLine(){
  height = 280;
  // Draw a line
  stroke(50);
  fill(100);
  line(40,y,560,y);
  
  // Jiggling randomly on the horizontal axis
 //x = x + random(-2, 2);
  // Moving up at a constant speed
 y = y - 2;
  
  // Reset to the bottom
  if (y < 40) {
    y = 250;
  }
  if(y > 300){
     y = 260
     }
}
function channel3(){
  noX = 240;
  signalX = 180;
  noX = noX + random(-1, 1);
  signalX = signalX + random(-1, 1);
  textSize(60);
  fill(0);
  text('NO', noX, 150);
  text('SIGNAL', signalX, 210);
}