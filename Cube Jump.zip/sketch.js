//global variables
let jumpPressed = false;
let level = 0;//0.main menu 1.play 2.scores 3.howtoplay
let alive = true;
let points = 0;
let px = 0;
let vx = 0;
var img2;
let a = 0;

const SAVE_KEY_SCORE = "highscore";
const SAVE_KEY_SCORE2 = "highscore2";
const SAVE_KEY_SCORE3 = "highscore3";
scoreHigh = localStorage.getItem(SAVE_KEY_SCORE);
scoreHigh2 = localStorage.getItem(SAVE_KEY_SCORE2);
scoreHigh3 = localStorage.getItem(SAVE_KEY_SCORE3);

function preload(){
  img1 = loadImage("data/spikes.png");
  //img2 = createImg("data/explosion.gif");
  img2 = createImg("data/smoke.gif");
  jumpSound = loadSound('data/jumpSound.wav');
  gameSound = loadSound('data/gameSound.mp3');
  songEnd = loadSound('data/songEnd.mp3');
  clickSound = loadSound('data/clickSound.wav');
}

// The player object
let p = {
  x: 100,
  y: 550,//550
  w: 30, 
  h: 30,
  vx: 0,//0
  vy: 0,
  anticipate: "FLOOR",
  onGround: false,
  colliding: false,
  jump: false,
  draw: function() {
    if(level == 1){
    fill(255,165,0)
    rect(this.x, this.y, this.w, this.h)
    }
    fill(34,225,75);
  },
  update: function() {
    if(level == 1 && alive == true){// && alive == true
    if(!this.onGround) {
        this.vy += 0.3;
        this.vx += .8
        this.vx *= 0.8
    } else {
        this.vy = 0;
        this.vx += .8
      if(keyIsDown(87) && jumpPressed) this.jump = true;
      if(this.jump){
        jumpSound.play();
        this.vy = -10;
        this.jump = false;
        this.onGround = false;
      }
      this.vx *= 0.8
    }
    this.y += this.vy;
    this.x += this.vx;
  }
    points = this.x;
    score(this.x, this.y);
    px = this.x;
    //console.log(this.x, this.y);
    if(alive == false){
      if(score(this.x, this.y) > scoreHigh){
         scoreHigh = score;
        localStorage.setItem(SAVE_KEY_SCORE, scoreHigh)
         }  
      death(p.x);
       }
}
}

// Function for generating rectangles
//function rectangle(x, y, w, h){
  //this.x = x;
  //this.y = y;
  //this.w = w;
  //this.h = h;
  //this.draw = function(){
  //rect(this.x, this.y, this.w, this.h)
  //}
//}

function rectangle(x, y, w, h){
  this.x = x;
  this.y = y;
  this.w = w;
  this.h = h;
  this.draw = function(){
    rect(this.x, this.y, this.w, this.h)
  }
}

function setup() {
  createCanvas(800, 600);
  //createCanvas(windowWidth, windowHeight);
  img2.hide();
  
 
 // if(alive == true){
   
 // }
  //else if(alive == false){
  //  gameSound.setVolume(0);
  //}
  
  frameRate(120);
  score();
  platforms();
  spike();  

  //camera
  origin = {
    x: width/3.5,
    y: height/2
  }
  center = {
    x: width/2,
    y: height/2
  }
    dx = center.x - p.x;
    dy = center.y - p.y;
}

x = 0;
function draw() {
  background(135,206,250);
  //consoleLog();
    
  
  if(alive == false && x == 0){
    gameSound.setVolume(0);
    songEnd.setVolume(.03);
    songEnd.play();
    x++;
  }

//if(alive == false){
  //console.log('E');
  //origin = {
  //  x: 0,//x: 750,
  //  y: 0//y: 300
  //}
  //center = {
   // x: 0,//x: 100,
   // y: 750//y: 100
  //}
  //  dx = center.x;
  //  dy = center.y;
//}
  
//  if(level == 0){
//  console.log('E');
//  origin = {
//    x: 250,//x: 750,
//    y: 300//y: 300
//  }
//  center = {
//    x: 1000,//x: 100,
 //   y: 100//y: 100
 // }
 //   dx = center.x;
 //   dy = center.y;
//}
  
  //camera movement
  dx = center.x - p.x;
  //dy = center.y - p.y;//allows camera to move on y axis with player
  dy = center.y - 530;
  if(abs(dx) > 100){
    center.x -= dx - 100 * dx / abs(dx)
  }
  if(abs(dy) > 100){
    center.y -= dy - 100 * dy / abs(dy)
  }
  translate(origin.x - center.x, origin.y - center.y)
  p.colliding = false;
  
  mainMenu();
  if(level == 0){
     mainMenu();
     }
  if(level==3){//how-to-play screen
    levelThree();
  }
  if(level==4){
    gameOverScreen(points, px);
  }
  if(level==2){
     level2();
     }
 
  
  if(level==1 && a == 0){
    gameSound.play();
    gameSound.setVolume(0.01);
    a++;
     }
  
  
  
  
  
  
  
  strokeWeight(1);
  noFill();
  //fill(135,206,250);
  //noStroke();
  strokeWeight(0);
  for(let i = 0; i < spikes.length; i++){
    //fill(220);
    //noFill();
    //noStroke();
    let r = spikes[i];
    image(img1,r.x,r.y-2,r.h+50,r.w-40);
    let top = new rectangle(r.x, r.y - 10, r.w, 10)
    let btm = new rectangle(r.x, r.y + r.h, r.w, 10)
    let lt = new rectangle(r.x - 10, r.y, 10, r.h)
    let rt = new rectangle(r.x + r.w, r.y, 10, r.h)
    
    
    // Additional Criteria or Smoother Gameplay
    if(rectCollision(lt, p) && p.vx > 0 && p.y + p.h - 10 > top.y + top.h){
      p.anticipate = "LEFT"
    }
    if(rectCollision(rt, p) && p.vx < 0 && p.y + p.h - 10 > top.y + top.h){
      p.anticipate = "RIGHT"
    }
    if(rectCollision(btm, p)) {
      p.anticipate = "CEILING"
    }
    if(rectCollision(top, p) && p.y + p.h-5 < top.y + top.h && p.vy > 0){
      p.anticipate = "FLOOR"
    } 
    
    if(rectCollision(p, r)){
      if(p.anticipate == "FLOOR"){
        p.vy = 0;
        p.y = r.y - p.h 
        p.onGround = true;
        p.colliding = true;
        alive = false;
      }
      if(p.anticipate == "CEILING"){
        if(p.vy < 0) {
          p.vy = 0;
          p.y = r.y + r.h
          alive = false;
        } 
        p.colliding = true;
      }
      if(p.anticipate == "RIGHT"){
        p.vx = 0;
        p.x = r.x + r.w
        p.colliding = true;
        alive = false;
      }
      if(p.anticipate == "LEFT"){
        p.vx = 0;
        p.x = r.x - p.w
        p.colliding = true;
        alive = false;
      }
    }
  }
  for(let i = 0; i < spikes.length; i++){
    spikes[i].draw()
  }
  strokeWeight(1);
 
  
  
  
  
  
  

  for(let i = 0; i < rects.length; i++){
    let r = rects[i];
    let top = new rectangle(r.x, r.y - 10, r.w, 10)
    let btm = new rectangle(r.x, r.y + r.h, r.w, 10)
    let lt = new rectangle(r.x - 10, r.y, 10, r.h)
    let rt = new rectangle(r.x + r.w, r.y, 10, r.h)
 
    // Additional Criteria or Smoother Gameplay
    if(rectCollision(lt, p) && p.vx > 0 && p.y + p.h - 10 > top.y + top.h){
      p.anticipate = "LEFT"
    }
    if(rectCollision(rt, p) && p.vx < 0 && p.y + p.h - 10 > top.y + top.h){
      p.anticipate = "RIGHT"
    }
    if(rectCollision(btm, p)) {
      p.anticipate = "CEILING"
    }
    if(rectCollision(top, p) && p.y + p.h-5 < top.y + top.h && p.vy > 0){
      p.anticipate = "FLOOR"
    } 
    
    if(rectCollision(p, r)){
      if(p.anticipate == "FLOOR"){
        p.vy = 0;
        p.y = r.y - p.h 
        p.onGround = true;
        p.colliding = true;
      }
      if(p.anticipate == "CEILING"){
        if(p.vy < 0) {
          p.vy = 0;
          p.y = r.y + r.h
        } 
        p.colliding = true;
      }
      if(p.anticipate == "RIGHT"){
        p.vx = 0;
        p.x = r.x + r.w
        p.colliding = true;
      }
      if(p.anticipate == "LEFT"){
        p.vx = 0;
        p.x = r.x - p.w
        p.colliding = true;
      }
    }  
  }
  
  if(!p.colliding) p.onGround = false
  p.update()
  p.draw()
  for(let i = 0; i < rects.length; i++){
    rects[i].draw()
  }
  jumpPressed = false;
}

function keyPressed(){
  if(keyCode == 87){
    jumpPressed = true;
    if(p.onGround) p.jump = true;
  } 
}

function rectCollision(r1, r2){
  if (
    r1.x < r2.x + r2.w &&
    r1.x + r1.w > r2.x &&
    r1.y < r2.y + r2.h &&
    r1.h + r1.y > r2.y
  ) {
    return true
  } else {
    // No collision
    return false
  }
}

function platforms() {
  rect2 = new rectangle(-100, height-40, 20000, 40);//floor
  rect3 = new rectangle(1200, height-180, 200, 40);
  rect4 = new rectangle(950, height-90, 200, 50);
  rect5 = new rectangle(1500, 300, 75, 50);
  rect6 = new rectangle(1750, 400, 150, 50);
  rect7 = new rectangle(2300, 510, 100, 50);
  rect8 = new rectangle(2500, 460, 200, 100);
  rect9 = new rectangle(2850, 385, 250, 175);
  rect10 = new rectangle(3200, 285, 300, 275);
  rect11 = new rectangle(4400, 450, 200, 50);
  rect12 = new rectangle(4750, 350, 150, 50);
  rect13 = new rectangle(4950, 450, 100, 50);
  rect14 = new rectangle(5200, 350, 75, 50);
  rect15 = new rectangle(5450, 250, 75, 40);
  rect16 = new rectangle(5650, 150, 75, 30);
  rect17 = new rectangle(5850, 450, 75, 20);
  rect18 = new rectangle(6000, 250, 75, 50);
  rect19 = new rectangle(6500, 250, 175, 150);
  rect19 = new rectangle(6700, 450, 50, 50);
  rect20 = new rectangle(6970, 450, 50, 50);
  rect21 = new rectangle(7150, 350, 50, 50);
  rect22 = new rectangle(7350, 250, 50, 50);
  rect23 = new rectangle(8600, 510, 150, 10);//
  rect24 = new rectangle(9200, 480, 150, 40);
  rect25 = new rectangle(9400, 380, 150, 40);
  rect26 = new rectangle(9800, 380, 150, 40);
  rect27 = new rectangle(9950, 480, 150, 40);
  rect28 = new rectangle(10150, 380, 150, 40);
  
  rects = [rect2, rect3, rect4, rect5, rect6, rect7, rect8, rect9, rect10, rect11, rect12, rect13, rect14, rect15, rect16, rect17, rect18, rect19, rect20, rect21, rect22, rect23, rect24, rect25, rect26, rect27, rect28 ];
}

function spike(){
  spike2 = new rectangle(1400,520,100,50);
  spike3 = new rectangle(1000,520,100,50);
  spike4 = new rectangle(850,520,100,50);
  spike5 = new rectangle(950,520,100,50);
  spike6 = new rectangle(1115,520,100,50);
  spike7 = new rectangle(2200,520,100,50);
  spike8 = new rectangle(2400,520,100,50);
  spike9 = new rectangle(2750,520,100,50);
  spike10 = new rectangle(2700,520,100,50);
  spike11 = new rectangle(3100,520,100,50);
  spike12 = new rectangle(1800,520,100,50);
  spike13 = new rectangle(3500,520,100,50);
  spike14 = new rectangle(3800,520,100,50);
  spike15 = new rectangle(4000,520,100,50);
  spike16 = new rectangle(4400,520,100,50);
  spike17 = new rectangle(4500,520,100,50);
  spike18 = new rectangle(4600,520,100,50);
  spike19 = new rectangle(4700,520,100,50); 
  spike20 = new rectangle(4800,520,100,50);
  spike21 = new rectangle(4900,520,100,50);
  spike22 = new rectangle(5000,520,100,50);
  spike23 = new rectangle(5100,520,100,50);
  spike24 = new rectangle(5200,520,100,50);
  spike25 = new rectangle(5300,520,100,50);
  spike26 = new rectangle(5400,520,100,50);
  spike27 = new rectangle(5500,520,100,50);
  spike28 = new rectangle(5600,520,100,50);
  spike29 = new rectangle(5700,520,100,50);
  spike30 = new rectangle(5800,520,100,50);
  spike31 = new rectangle(5900,520,100,50);
  spike32 = new rectangle(6200,520,100,50);
  spike33 = new rectangle(6700,520,100,50);
  spike34 = new rectangle(6800,520,100,50);
  spike35 = new rectangle(6900,520,100,50);
  spike36 = new rectangle(7000,520,100,50);
  spike37 = new rectangle(7100,520,100,50);
  spike38 = new rectangle(7200,520,100,50);
  spike39 = new rectangle(7300,520,100,50);
  spike40 = new rectangle(7400,520,100,50);
  spike41 = new rectangle(7650,520,100,50);
  spike42 = new rectangle(8000,520,100,50);
  spike43 = new rectangle(8200,520,100,50);
  spike44 = new rectangle(8450,520,100,50);
  spike45 = new rectangle(9200,520,100,50);
  spike46 = new rectangle(9300,520,100,50);
  spike47 = new rectangle(9400,520,100,50);
  spike48 = new rectangle(9500,520,100,50);
  spike49 = new rectangle(9600,520,100,50);
  spike50 = new rectangle(9700,520,100,50);
  spike51 = new rectangle(9800,520,100,50);
  spike52 = new rectangle(9900,520,100,50);
  spike53 = new rectangle(10000,520,100,50);
  spike54 = new rectangle(10100,520,100,50);
  spike55 = new rectangle(10200,520,100,50);
  spike56 = new rectangle(10300,520,100,50);
  spike57 = new rectangle(10400,520,100,50);
  spike58 = new rectangle(8550,520,100,50);
  spike59 = new rectangle(8650,520,100,50);

  
  
  spikes = [spike2, spike3, spike4, spike5, spike6, spike7, spike8, spike9, spike10, spike11, spike12, spike13, spike14, spike15, spike16, spike17, spike18, spike19, spike20, spike21, spike22, spike23, spike24, spike25, spike26, spike27, spike28, spike29, spike30, spike31, spike32, spike33, spike34, spike35, spike36, spike37, spike38, spike39, spike40, spike41, spike42, spike43, spike44, spike45, spike46, spike47, spike48, spike49, spike50, spike51, spike52, spike53, spike54, spike55, spike56, spike57, spike58, spike59];
}

function mainMenu(){
    if(level == 0){//main menu
    let colora = "";
    let color1 = "0, 102, 153"; 
    let color2 = "255,165,0";  
    let a = 529;
      
      
      //if(level == 0){
  //console.log('E');
  //origin = {
  //  x: px-80,//x: 750,
  //  y: 300//y: 300
  //}
  //center = {
  //  x: 0,//x: 100,
  //  y: 0//y: 100
  //}
  //  dx = center.x;
  //  dy = center.y;
//}
      
      
    textSize(100);
    text('Cube Jump', center.x-100,center.y-150);
    textSize(103);
    fill(0, 102, 153)
    text('Cube Jump', center.x-107,center.y-150);
    //text('Cube Jump', 100, 280);
      
    //rect(190,482,340,50);
    fill(255,165,0); 
    rect(105,296,450,5);
    fill(0, 102, 153); 
    rect(110,293,450,5);
    
    if (mouseX > 220 && mouseX < 558 && mouseY > 190 && mouseY < 240){
      rect(190-15,322-12,340+27,50+20);
      fill(255,165,0);
      textSize(65);
      text('Play', 295, 365);
      fill(0, 102, 153);
      a = a - 200;
      if (mouseIsPressed){
        playClick();
        level = 1;
          }
    }else{
      fill(255,165,0);
      rect(190,322,340,50);
      textSize(50);
      fill(0, 102, 153);
      text('Play', 300, 360);  
    }  
      
    if (mouseX > 220 && mouseX < 558 && mouseY > 270 && mouseY < 320){
      rect(190-15,400-12,340+27,50+20);
      fill(255,165,0);
      textSize(65);
      text('Score', 270, 445);
      fill(0, 102, 153);
      a = a - 120;
      if (mouseIsPressed){
        playClick();
        level = 2;
      }
    }else{
      fill(255,165,0);
      rect(190,400,340,50);
      textSize(50);
      fill(0, 102, 153);
      text('Score', 290, 440);
    }
      
    if (mouseX > 220 && mouseX < 558 && mouseY > 350 && mouseY < 400){
      rect(190-15,482-12,340+27,50+20);
      fill(255,165,0);
      textSize(65);
      text('How-to-Play', 185, 522);
      fill(0, 102, 153);
      a = a - 40;
      if (mouseIsPressed){
        playClick();
        level = 3;
      }
    }else{ 
      fill(255,165,0);
      rect(190,482,340,50);
      textSize(50);
      fill(0, 102, 153);
      text('How-to-Play', 230, 520);
    }
    fill(255,165,0)
    rect(50, a, 30, 30)   
    }
}

function consoleLog(){
  console.log("| MouseX = " + mouseX + " || " + "MouseY = " + mouseY + " |");
}

function levelThree(){//how-to-play screen
  //title    
  textSize(50);
  fill(0, 102, 153);
  text('How-to-Play', 210, 220);
  fill(255,165,0); 
  rect(200,235,350,5);
  
  //controls
  fill(0, 102, 153);
  text('Controls:', 0, 320);
  text('W  = JUMP', 65, 387);
  noFill();
  strokeWeight(5);
  rect(50,330,80,80);
  strokeWeight(1);
  
  //instructions
  fill(0, 102, 153);
  textSize(20);
  text('-Use the jump key to jump over and on \nboxes.\n\n-Avoid spikes and other obstacles!\n\n-Travel as far as possible to gain points.', 380, 320);
  
  
  //return arrow
  if (mouseX > 30 && mouseX < 210 && mouseY > 50 && mouseY < 100){
    rect(0,180,180,50);
    fill(0, 102, 153);
    line(15,205,135,205);
    line(15,205,85, 220);
    line(15,205,85,185);
    if (mouseIsPressed){
      playClick();
      level = 0;
    }
  }else{
    fill(255,165,0);
    rect(0,180,180,50);
    line(30,205,150,205);
    line(30,205,100, 220);
    line(30,205,100,185);
  }
}//how-to-play

function score(x, y){
  function points(){
    let score = round(x/200);
          if(score > scoreHigh){
         scoreHigh = score;
        localStorage.setItem(SAVE_KEY_SCORE, scoreHigh)
         } 
        else if(score > scoreHigh2 && score < scoreHigh){
          localStorage.setItem(SAVE_KEY_SCORE2, scoreHigh2)        
            }
    //console.log(score);
    return score;
  }
  let scoreY = 175;
  //if(y < 240){
     //scoreY = y-150;
  //}
  
  points(x);
  fill(255,165,0);
  rect(x-280,180,100,50);
  fill(0, 102, 153);
  textSize(34);
  text('Score: \n  ' + points(x), x-278, scoreY);
  //console.log(x, y);
  //text("GAME OVER", 820, 530 );
}

function death(x){
  //console.log("GAME OVER SCREEN" + x);
  //localStorage.setItem('myCar', 'x');
  fill(0, 102, 153);
  textSize(90);
  //text("GAME OVER", x-200, 350 );
  noFill();
  alive = false;
  level = 4;
}

function gameOverScreen(score, px){
  //image(img2,px,100);
  //image(gif ,px, 100);

  

    if(alive == false){
      img2.show();
      img2.position(dx+200,dy+200)//100);
    }
    else {
      img2.position(dx+930,1350);
    }  

    
  textSize(100);
  fill(255,165,0);
  text('GAME OVER', px-154, 235);
  fill(0, 102, 153);
  rect(px-170,245,630,10);
  
  textSize(102);
  text('GAME OVER', px-160, 230);
  fill(255,165,0);
  rect(px-175,250,630,10);

  if(mouseX > 415 && mouseX < 760 && mouseY > 510 && mouseY < 560){
      fill(0, 102, 153);
      rect(px+65,635,380,60);
      textSize(60);
      fill(255,165,0);
      text('Main Menu', px+120, 685);    
      if (mouseIsPressed){
        //level = 0;
        //console.log(level);
        //setup();
        //draw();
        //px=-1000;
        //mainMenu();
        //reset();
      }
  }else{
      fill(255,165,0);
      rect(px+90,641,340,50);
      textSize(50);
      fill(0, 102, 153);
      text('Main Menu', px+135, 680);
  }
  
    if(mouseX > 40 && mouseX < 385 && mouseY > 510 && mouseY < 560){
      fill(0, 102, 153);
      rect(px-295,635,380,60);
      textSize(60);
      fill(255,165,0);
      text('Try Again', px-228, 680);
    }else{
      fill(255,165,0);
      rect(px-285,641,340,50);
      textSize(50);
      fill(0, 102, 153);
      text('Try Again', px-220, 680);
    }
  //if(level == 0){
    //mainMenu();
    
    //}
}

function reset2(){
    createCanvas(800, 600);
  //createCanvas(window.screen.width,window.screen.height);
  frameRate(120);
  score();
  platforms();
  spike();  

  //camera
  origin = {
    x: width/3.5,
    y: height/2
  }
  center = {
    x: width/2,
    y: height/2
  }
    dx = center.x - p.x;
    dy = center.y - p.y;
}

function level2(){//score screen
  var scoreStr = localStorage.getItem(SAVE_KEY_SCORE);
  if(scoreStr == null){
    scoreHigh = 1;
  }
  else{
    if(scoreHigh > score){
    scoreHigh = parseInt(scoreStr);
    }
  }
  
  //var scoreStr2 = localStorage.getItem(SAVE_KEY_SCORE2);
  //if(scoreStr2 == null){
  //  scoreHigh2 = 1;
  //}
  //else{
  //  if(scoreHigh2 > score ){//&& scoreHigh < score){
  //  scoreHigh2 = parseInt(scoreStr2);
  //  }
  //}
  fill(0, 102, 153);
  rect(325,315,250,100);
  
  fill(255,165,0);
  textSize(100);
  text('' + scoreHigh, 400, 400);
  //text('High Score 2: ' + scoreHigh2, 300, 400);
  
  textSize(90);
  fill(0, 102, 153);
  text('High Score:', 225, 240);
  fill(255,165,0); 
  rect(185,260,550,5);
  
    if(mouseX > 215 && mouseX < 560 && mouseY > 510 && mouseY < 560){
      fill(0, 102, 153);
      rect(px+65,635,380,60);
      textSize(60);
      fill(255,165,0);
      text('Reset Score', px+80, 685);  
      if (mouseIsPressed){
        localStorage.clear();
      }
  }else{
      fill(255,165,0);
      rect(px+90,641,340,50);
      textSize(50);
      fill(0, 102, 153);
      text('Reset Score', px+110, 680);
  }
  //return arrow
  if (mouseX > 30 && mouseX < 210 && mouseY > 50 && mouseY < 100){
    rect(0,180,180,50);
    fill(0, 102, 153);
    line(15,205,135,205);
    line(15,205,85, 220);
    line(15,205,85,185);
    if (mouseIsPressed){
      playClick();
      level = 0;
    }
  }else{
    fill(255,165,0);
    rect(0,180,180,50);
    line(30,205,150,205);
    line(30,205,100, 220);
    line(30,205,100,185);
  }
}



function playClick(){
  clickSound.play();
}